#include "func.h"

int main()
{
	write(1,"xiongda",7);
	return 0;
}
